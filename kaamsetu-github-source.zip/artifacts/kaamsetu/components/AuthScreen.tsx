import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';
import { useAuth } from '@/context/AuthContext';

export function AuthScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topInset = Math.max(insets.top, 44);
  const { signIn } = useAuth();
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const sendOtp = () => {
    const normalized = phone.replace(/\D/g, '');
    if (normalized.length !== 10) {
      setError('Enter a valid 10-digit mobile number.');
      return;
    }
    setError('');
    setStep('otp');
  };

  const verifyOtp = async () => {
    if (otp !== '123456') {
      setError('That OTP is not correct. Try 123456 for this demo.');
      return;
    }
    setError('');
    setIsSubmitting(true);
    await signIn(phone.replace(/\D/g, ''));
    setIsSubmitting(false);
  };

  return (
    <>
      <StatusBar style="dark" hidden={false} backgroundColor={colors.background} />
      <SafeAreaView style={[styles.root, { backgroundColor: colors.background, paddingTop: Math.max(topInset - insets.top, 0) }]} edges={['top', 'left', 'right']}>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 28 }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.brandRow}>
          <View style={[styles.logo, { backgroundColor: colors.primary }]}>
            <Feather name="git-merge" size={23} color={colors.primaryForeground} />
          </View>
          <View>
            <Text style={[styles.brand, { color: colors.foreground }]}>KaamSetu</Text>
            <Text style={[styles.tagline, { color: colors.mutedForeground }]}>काम का भरोसेमंद पुल</Text>
          </View>
        </View>

        <View style={styles.intro}>
          <View style={[styles.welcomeIcon, { backgroundColor: colors.accent }]}>
            <Feather name={step === 'phone' ? 'smartphone' : 'message-square'} size={24} color={colors.primary} />
          </View>
          <Text style={[styles.title, { color: colors.foreground }]}>
            {step === 'phone' ? 'Welcome to KaamSetu' : 'Enter your OTP'}
          </Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            {step === 'phone'
              ? 'Find trusted local work or hire reliable help near you.'
              : `We sent a 6-digit code to +91 ${phone.replace(/\D/g, '')}.`}
          </Text>
        </View>

        <View style={[styles.formCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {step === 'phone' ? (
            <>
              <Text style={[styles.label, { color: colors.foreground }]}>Mobile number</Text>
              <View style={[styles.inputRow, { backgroundColor: colors.background, borderColor: error ? colors.destructive : colors.input }]}>
                <Text style={[styles.countryCode, { color: colors.foreground }]}>+91</Text>
                <View style={[styles.inputDivider, { backgroundColor: colors.border }]} />
                <TextInput
                  autoFocus
                  value={phone}
                  onChangeText={(value) => { setPhone(value.replace(/\D/g, '').slice(0, 10)); setError(''); }}
                  placeholder="Enter mobile number"
                  placeholderTextColor={colors.mutedForeground}
                  keyboardType="phone-pad"
                  style={[styles.input, { color: colors.foreground }]}
                  testID="phone-input"
                />
              </View>
              <Text style={[styles.helper, { color: colors.mutedForeground }]}>No email or password needed.</Text>
              <Pressable onPress={sendOtp} style={[styles.primaryButton, { backgroundColor: colors.primary }]} testID="send-otp-button">
                <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>Send OTP</Text>
                <Feather name="arrow-right" size={17} color={colors.primaryForeground} />
              </Pressable>
            </>
          ) : (
            <>
              <View style={styles.otpHeading}>
                <Text style={[styles.label, { color: colors.foreground }]}>6-digit OTP</Text>
                <Pressable onPress={() => { setStep('phone'); setOtp(''); setError(''); }}>
                  <Text style={[styles.changeNumber, { color: colors.primary }]}>Change number</Text>
                </Pressable>
              </View>
              <TextInput
                autoFocus
                value={otp}
                onChangeText={(value) => { setOtp(value.replace(/\D/g, '').slice(0, 6)); setError(''); }}
                placeholder="000000"
                placeholderTextColor={colors.mutedForeground}
                keyboardType="number-pad"
                maxLength={6}
                style={[styles.otpInput, { color: colors.foreground, borderColor: error ? colors.destructive : colors.input, backgroundColor: colors.background }]}
                testID="otp-input"
              />
              <View style={[styles.demoNote, { backgroundColor: colors.accent }]}>
                <Feather name="info" size={14} color={colors.accentForeground} />
                <Text style={[styles.demoText, { color: colors.accentForeground }]}>Demo OTP: 123456</Text>
              </View>
              <Pressable disabled={isSubmitting} onPress={verifyOtp} style={[styles.primaryButton, { backgroundColor: colors.primary, opacity: isSubmitting ? 0.6 : 1 }]} testID="verify-otp-button">
                <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>{isSubmitting ? 'Verifying…' : 'Verify and continue'}</Text>
                <Feather name="check" size={17} color={colors.primaryForeground} />
              </Pressable>
              <Pressable onPress={() => setError('A new demo OTP is 123456.')} style={styles.resendButton}>
                <Text style={[styles.resendText, { color: colors.primary }]}>Resend OTP</Text>
              </Pressable>
            </>
          )}
          {error ? (
            <View style={styles.errorRow}>
              <Feather name="alert-circle" size={14} color={colors.destructive} />
              <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
            </View>
          ) : null}
        </View>

        <View style={styles.trustRow}>
          <Feather name="shield" size={16} color={colors.primary} />
          <Text style={[styles.trustText, { color: colors.mutedForeground }]}>Your number is private and protected.</Text>
        </View>
      </KeyboardAwareScrollViewCompat>
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 22 },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logo: { width: 43, height: 43, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  brand: { fontSize: 22, fontFamily: 'Inter_700Bold', letterSpacing: -0.5 },
  tagline: { fontSize: 10, fontFamily: 'Inter_500Medium', marginTop: 1 },
  intro: { alignItems: 'center', marginTop: 76, marginBottom: 24 },
  welcomeIcon: { width: 58, height: 58, borderRadius: 20, alignItems: 'center', justifyContent: 'center', marginBottom: 17 },
  title: { fontSize: 26, fontFamily: 'Inter_700Bold', letterSpacing: -0.7, textAlign: 'center' },
  subtitle: { fontSize: 13, lineHeight: 20, fontFamily: 'Inter_400Regular', textAlign: 'center', marginTop: 8, maxWidth: 300 },
  formCard: { borderRadius: 20, borderWidth: 1, padding: 17 },
  label: { fontSize: 12, fontFamily: 'Inter_700Bold', marginBottom: 8 },
  inputRow: { height: 52, borderRadius: 13, borderWidth: 1, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 13 },
  countryCode: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
  inputDivider: { width: 1, height: 22, marginHorizontal: 11 },
  input: { flex: 1, fontSize: 14, fontFamily: 'Inter_400Regular' },
  helper: { fontSize: 10, fontFamily: 'Inter_400Regular', marginTop: 8, marginBottom: 19 },
  primaryButton: { height: 52, borderRadius: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9 },
  primaryButtonText: { fontSize: 13, fontFamily: 'Inter_700Bold' },
  otpHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  changeNumber: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  otpInput: { height: 59, borderWidth: 1, borderRadius: 13, textAlign: 'center', letterSpacing: 9, fontSize: 25, fontFamily: 'Inter_700Bold', marginBottom: 10 },
  demoNote: { borderRadius: 10, padding: 9, flexDirection: 'row', alignItems: 'center', gap: 7, marginBottom: 15 },
  demoText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  resendButton: { alignItems: 'center', paddingVertical: 14 },
  resendText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  errorRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 11 },
  errorText: { flex: 1, fontSize: 11, lineHeight: 16, fontFamily: 'Inter_500Medium' },
  trustRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, marginTop: 20 },
  trustText: { fontSize: 11, fontFamily: 'Inter_400Regular' },
});