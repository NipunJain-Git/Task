import React, { useState } from 'react';
import { Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { Language, useLanguage } from '@/context/LanguageContext';

export function LanguageMenu() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { language, setLanguage, languages } = useLanguage();
  const [open, setOpen] = useState(false);
  const languageCode = language === 'English' ? 'EN' : language === 'हिंदी' ? 'हि' : language === 'ગુજરાતી' ? 'ગુ' : 'मर';

  const choose = (next: Language) => {
    setLanguage(next);
    setOpen(false);
  };

  return (
    <>
      <Pressable onPress={() => setOpen(true)} style={[styles.button, { backgroundColor: colors.card, borderColor: colors.border }]} testID="language-button">
        <Text style={[styles.code, { color: colors.foreground }]}>{languageCode}</Text>
        <Feather name="chevron-down" size={13} color={colors.mutedForeground} />
      </Pressable>
      <Modal visible={open} animationType="fade" transparent onRequestClose={() => setOpen(false)}>
        <Pressable style={styles.backdrop} onPress={() => setOpen(false)}>
          <View style={[styles.menu, { backgroundColor: colors.card, borderColor: colors.border, top: insets.top + 64 }]}>
            <Text style={[styles.menuTitle, { color: colors.mutedForeground }]}>LANGUAGE / भाषा</Text>
            {languages.map((item) => (
              <Pressable key={item} onPress={() => choose(item)} style={styles.item}>
                <Text style={[styles.itemText, { color: colors.foreground }]}>{item}</Text>
                {language === item ? <Feather name="check" size={16} color={colors.primary} /> : null}
              </Pressable>
            ))}
          </View>
        </Pressable>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  button: { height: 34, paddingHorizontal: 9, borderRadius: 10, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 4 },
  code: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  backdrop: { flex: 1 },
  menu: { position: 'absolute', right: 20, width: 180, borderWidth: 1, borderRadius: 15, paddingVertical: 7, shadowColor: '#18233A', shadowOpacity: 0.14, shadowRadius: 12, elevation: 6 },
  menuTitle: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 0.8, paddingHorizontal: 13, paddingVertical: 7 },
  item: { height: 38, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  itemText: { fontSize: 12, fontFamily: 'Inter_500Medium' },
});