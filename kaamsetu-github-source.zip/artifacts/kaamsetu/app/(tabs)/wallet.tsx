import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useLanguage } from '@/context/LanguageContext';
import { LanguageMenu } from '@/components/LanguageMenu';
import { WalletPinModal } from '@/components/WalletPinModal';

type Transaction = { id: string; title: string; date: string; amount: string; type: 'credit' | 'debit'; icon: keyof typeof Feather.glyphMap };

const initialTransactions: Transaction[] = [
  { id: '1', title: 'Job payout · Wall painting', date: 'Today, 12:45 PM', amount: '+ ₹1,200', type: 'credit', icon: 'briefcase' },
  { id: '2', title: 'Sent to Meena', date: 'Yesterday, 6:20 PM', amount: '- ₹500', type: 'debit', icon: 'send' },
  { id: '3', title: 'Wallet top up', date: '18 Jun, 9:15 AM', amount: '+ ₹2,000', type: 'credit', icon: 'arrow-down-left' },
];

export default function WalletScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topInset = Math.max(insets.top + 14, 34);
  const { t } = useLanguage();
  const [balance, setBalance] = useState(2840);
  const [filter, setFilter] = useState<'all' | 'credit' | 'debit'>('all');
  const [transactions, setTransactions] = useState(initialTransactions);
  const [pinRequest, setPinRequest] = useState<{ amount: number; type: 'add' | 'send' } | null>(null);

  const addMoney = (amount: number) => {
    setBalance((value) => value + amount);
    setTransactions((items) => [{ id: `${Date.now()}`, title: 'Wallet top up', date: 'Just now', amount: `+ ₹${amount.toLocaleString('en-IN')}`, type: 'credit', icon: 'arrow-down-left' }, ...items]);
    Alert.alert('Money added', `₹${amount.toLocaleString('en-IN')} has been added to your wallet.`);
  };

  const sendToFamily = (amount: number) => {
    if (balance < amount) {
      Alert.alert('Insufficient balance', 'Add money before sending a family transfer.');
      return;
    }
    setBalance((value) => value - amount);
    setTransactions((items) => [{ id: `${Date.now()}`, title: 'Sent to Meena', date: 'Just now', amount: `- ₹${amount.toLocaleString('en-IN')}`, type: 'debit', icon: 'send' }, ...items]);
    Alert.alert('Transfer complete', `₹${amount.toLocaleString('en-IN')} sent to Meena securely.`);
  };

  const visibleTransactions = transactions.filter((transaction) => filter === 'all' || transaction.type === filter);

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 98 }}>
        <View style={[styles.header, { paddingTop: topInset }]}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>{t('safeAndSimple')}</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>{t('myWallet')}</Text>
          </View>
          <View style={styles.headerActions}>
            <LanguageMenu />
            <View style={[styles.pinBadge, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Feather name="lock" size={14} color={colors.primary} />
              <Text style={[styles.pinText, { color: colors.foreground }]}>{t('pinOn')}</Text>
            </View>
          </View>
        </View>

        <View style={styles.body}>
          <View style={[styles.balanceCard, { backgroundColor: colors.indigo }]}>
            <View style={styles.balanceHeader}>
              <Text style={styles.balanceLabel}>{t('walletBalance')}</Text>
              <View style={styles.balanceIcon}><Feather name="shield" size={19} color="#FFFFFF" /></View>
            </View>
            <Text style={styles.balance}>₹{balance.toLocaleString('en-IN')}</Text>
            <Text style={styles.secureText}><Feather name="check-circle" size={13} color="#DCE5FF" /> Secure wallet · Balance available</Text>
          </View>

          <View style={styles.actionsRow}>
            <Pressable onPress={() => setPinRequest({ amount: 500, type: 'add' })} style={[styles.actionButton, { backgroundColor: colors.primary }]}>
              <View style={styles.actionIconLight}><Feather name="plus" size={19} color={colors.primary} /></View>
              <Text style={[styles.actionLabel, { color: colors.primaryForeground }]}>{t('addMoney')}</Text>
            </Pressable>
            <Pressable onPress={() => setPinRequest({ amount: 500, type: 'send' })} style={[styles.actionButton, { backgroundColor: colors.card, borderColor: colors.border, borderWidth: 1 }]}>
              <View style={[styles.actionIconLight, { backgroundColor: colors.accent }]}><Feather name="send" size={18} color={colors.accentForeground} /></View>
              <Text style={[styles.actionLabel, { color: colors.foreground }]}>{t('sendToFamily')}</Text>
            </Pressable>
          </View>

          <View style={[styles.familyCard, { backgroundColor: colors.accent }]}>
            <View style={[styles.familyIcon, { backgroundColor: colors.primary }]}><Feather name="heart" size={17} color={colors.primaryForeground} /></View>
            <View style={styles.familyCopy}>
              <Text style={[styles.familyTitle, { color: colors.foreground }]}>{t('familySafety')}</Text>
              <Text style={[styles.familySub, { color: colors.mutedForeground }]}>Meena · Spouse · •••• 7633</Text>
            </View>
            <Feather name="check-circle" size={18} color="#2D8A4B" />
          </View>

          <View style={styles.sectionHeading}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{t('transactionReceipts')}</Text>
            <Pressable><Feather name="download" size={17} color={colors.primary} /></Pressable>
          </View>
          <View style={[styles.tabs, { backgroundColor: colors.muted }]}>
            {(['all', 'credit', 'debit'] as const).map((item) => (
              <Pressable key={item} onPress={() => setFilter(item)} style={[styles.tab, filter === item && { backgroundColor: colors.card }]}>
                <Text style={[styles.tabText, { color: filter === item ? colors.foreground : colors.mutedForeground }]}>{item === 'all' ? t('all') : item === 'credit' ? t('credit') : t('debit')}</Text>
              </Pressable>
            ))}
          </View>

          <View style={[styles.transactionList, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {visibleTransactions.map((transaction) => (
              <View key={transaction.id} style={[styles.transaction, { borderBottomColor: colors.border }]}>
                <View style={[styles.transactionIcon, { backgroundColor: transaction.type === 'credit' ? '#E4F4EA' : '#FBEAE6' }]}>
                  <Feather name={transaction.icon} size={16} color={transaction.type === 'credit' ? '#2D8A4B' : '#B85B4A'} />
                </View>
                <View style={styles.transactionCopy}>
                  <Text style={[styles.transactionTitle, { color: colors.foreground }]}>{transaction.title}</Text>
                  <Text style={[styles.transactionDate, { color: colors.mutedForeground }]}>{transaction.date} · REC-{transaction.id.slice(-4).padStart(4, '0')}</Text>
                </View>
                <Text style={[styles.transactionAmount, { color: transaction.type === 'credit' ? '#2D8A4B' : colors.foreground }]}>{transaction.amount}</Text>
              </View>
            ))}
          </View>
          <Text style={[styles.pinNote, { color: colors.mutedForeground }]}><Feather name="lock" size={12} color={colors.mutedForeground} /> Every transfer is authorized with your 4-digit Wallet PIN.</Text>
        </View>
      </ScrollView>
      <WalletPinModal
        visible={Boolean(pinRequest)}
        amount={pinRequest?.amount ?? 0}
        actionLabel={pinRequest?.type === 'send' ? 'sending' : 'adding'}
        onClose={() => setPinRequest(null)}
        onSuccess={() => {
          if (pinRequest?.type === 'add') addMoney(pinRequest.amount);
          else if (pinRequest?.type === 'send') sendToFamily(pinRequest.amount);
          setPinRequest(null);
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 19, flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
  eyebrow: { fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 1.1, marginBottom: 5 },
  title: { fontSize: 27, fontFamily: 'Inter_700Bold', letterSpacing: -0.7 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  pinBadge: { height: 32, borderRadius: 10, borderWidth: 1, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', gap: 5 },
  pinText: { fontSize: 10, fontFamily: 'Inter_700Bold' },
  body: { paddingHorizontal: 20 },
  balanceCard: { borderRadius: 20, padding: 18, marginBottom: 13 },
  balanceHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  balanceLabel: { color: '#DCE5FF', fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 1.1 },
  balanceIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: 'rgba(255,255,255,0.13)', alignItems: 'center', justifyContent: 'center' },
  balance: { color: '#FFFFFF', fontSize: 34, fontFamily: 'Inter_700Bold', letterSpacing: -1, marginTop: 6 },
  secureText: { color: '#DCE5FF', fontSize: 10, fontFamily: 'Inter_500Medium', marginTop: 20 },
  actionsRow: { flexDirection: 'row', gap: 10, marginBottom: 13 },
  actionButton: { flex: 1, minHeight: 84, borderRadius: 16, padding: 12, justifyContent: 'space-between' },
  actionIconLight: { width: 30, height: 30, borderRadius: 10, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center' },
  actionLabel: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  familyCard: { minHeight: 69, borderRadius: 16, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 27 },
  familyIcon: { width: 35, height: 35, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  familyCopy: { flex: 1 },
  familyTitle: { fontSize: 12, fontFamily: 'Inter_700Bold' },
  familySub: { fontSize: 10, fontFamily: 'Inter_400Regular', marginTop: 3 },
  sectionHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 11 },
  sectionTitle: { fontSize: 17, fontFamily: 'Inter_700Bold', letterSpacing: -0.3 },
  tabs: { height: 38, borderRadius: 11, padding: 4, flexDirection: 'row', marginBottom: 11 },
  tab: { flex: 1, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  tabText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  transactionList: { borderWidth: 1, borderRadius: 16, paddingHorizontal: 13 },
  transaction: { minHeight: 69, borderBottomWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 10 },
  transactionIcon: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  transactionCopy: { flex: 1 },
  transactionTitle: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  transactionDate: { fontSize: 9, fontFamily: 'Inter_400Regular', marginTop: 4 },
  transactionAmount: { fontSize: 12, fontFamily: 'Inter_700Bold' },
  pinNote: { textAlign: 'center', fontSize: 10, fontFamily: 'Inter_400Regular', marginTop: 14 },
});