/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#18233A',
    tint: '#F47A45',
    indigo: '#26395F',

    // Core surfaces
    background: '#F8F5F0',
    foreground: '#18233A',

    // Cards / elevated surfaces
    card: '#FFFFFF',
    cardForeground: '#18233A',

    // Primary action color (buttons, links, active states)
    primary: '#F47A45',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#EEF0F5',
    secondaryForeground: '#18233A',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#F0EDE7',
    mutedForeground: '#6D7485',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#FFF0E8',
    accentForeground: '#B54C26',

    // Destructive actions (delete, error states)
    destructive: '#D94B4B',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#E3E2DF',
    input: '#D8D9DE',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 16,
};

export default colors;
