import React, { useState } from 'react';
import { Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

export function WalletPinModal({
  visible,
  amount,
  actionLabel,
  onClose,
  onSuccess,
}: {
  visible: boolean;
  amount: number;
  actionLabel: string;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  const close = () => {
    setPin('');
    setError('');
    onClose();
  };

  const confirm = () => {
    if (pin !== '1234') {
      setError('Incorrect PIN. Please try again.');
      setPin('');
      return;
    }
    setPin('');
    setError('');
    onSuccess();
  };

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={close}>
      <View style={[styles.backdrop, { backgroundColor: 'rgba(24,35,58,0.42)' }]}>
        <View style={[styles.sheet, { backgroundColor: colors.background, paddingBottom: insets.bottom + 18 }]}>
          <View style={styles.handle} />
          <View style={styles.icon}><Feather name="lock" size={20} color={colors.primary} /></View>
          <Text style={[styles.title, { color: colors.foreground }]}>Enter Wallet PIN</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            Enter your 4-digit PIN to authorize {actionLabel.toLowerCase()} ₹{amount.toLocaleString('en-IN')}.
          </Text>
          <TextInput
            autoFocus
            value={pin}
            onChangeText={(value) => { setPin(value.replace(/\D/g, '').slice(0, 4)); setError(''); }}
            keyboardType="number-pad"
            maxLength={4}
            secureTextEntry
            placeholder="••••"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.pinInput, { color: colors.foreground, backgroundColor: colors.card, borderColor: error ? colors.destructive : colors.input }]}
            testID="wallet-pin-input"
          />
          <View style={[styles.demoNote, { backgroundColor: colors.accent }]}>
            <Feather name="info" size={14} color={colors.accentForeground} />
            <Text style={[styles.demoText, { color: colors.accentForeground }]}>Demo Wallet PIN: 1234</Text>
          </View>
          {error ? (
            <View style={styles.errorRow}>
              <Feather name="alert-circle" size={14} color={colors.destructive} />
              <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
            </View>
          ) : null}
          <Pressable disabled={pin.length !== 4} onPress={confirm} style={[styles.confirmButton, { backgroundColor: pin.length === 4 ? colors.primary : colors.input }]}>
            <Text style={[styles.confirmText, { color: pin.length === 4 ? colors.primaryForeground : colors.mutedForeground }]}>Confirm securely</Text>
            <Feather name="check" size={17} color={pin.length === 4 ? colors.primaryForeground : colors.mutedForeground} />
          </Pressable>
          <Pressable onPress={close} style={styles.cancel}>
            <Text style={[styles.cancelText, { color: colors.mutedForeground }]}>Cancel</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, justifyContent: 'flex-end' },
  sheet: { borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingHorizontal: 20, paddingTop: 10 },
  handle: { width: 36, height: 4, borderRadius: 2, backgroundColor: '#D4D5D8', alignSelf: 'center', marginBottom: 21 },
  icon: { width: 46, height: 46, borderRadius: 16, backgroundColor: '#FFF0E8', alignItems: 'center', justifyContent: 'center', alignSelf: 'center', marginBottom: 12 },
  title: { textAlign: 'center', fontSize: 22, fontFamily: 'Inter_700Bold', letterSpacing: -0.5 },
  subtitle: { textAlign: 'center', fontSize: 12, lineHeight: 18, fontFamily: 'Inter_400Regular', marginTop: 7, marginHorizontal: 20 },
  pinInput: { height: 60, borderWidth: 1, borderRadius: 14, textAlign: 'center', letterSpacing: 12, fontSize: 25, fontFamily: 'Inter_700Bold', marginTop: 20 },
  demoNote: { borderRadius: 10, padding: 9, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, marginTop: 10 },
  demoText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  errorRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 10 },
  errorText: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  confirmButton: { height: 52, borderRadius: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9, marginTop: 15 },
  confirmText: { fontSize: 13, fontFamily: 'Inter_700Bold' },
  cancel: { height: 45, alignItems: 'center', justifyContent: 'center' },
  cancelText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
});