import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { ReactNode, createContext, useContext, useEffect, useMemo, useState } from 'react';

type AuthContextValue = {
  isSignedIn: boolean;
  isLoading: boolean;
  signIn: (phone: string) => Promise<void>;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);
const AUTH_KEY = '@kaamsetu/signed-in-phone';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [phone, setPhone] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    AsyncStorage.getItem(AUTH_KEY)
      .then((storedPhone) => setPhone(storedPhone))
      .finally(() => setIsLoading(false));
  }, []);

  const value = useMemo(
    () => ({
      isSignedIn: Boolean(phone),
      isLoading,
      signIn: async (nextPhone: string) => {
        await AsyncStorage.setItem(AUTH_KEY, nextPhone);
        setPhone(nextPhone);
      },
      signOut: async () => {
        await AsyncStorage.removeItem(AUTH_KEY);
        setPhone(null);
      },
    }),
    [isLoading, phone],
  );

  return <AuthContext.Provider value={value}>{isLoading ? null : children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}