# KaamSetu

KaamSetu is an Expo + React Native mobile app for connecting daily-wage workers with nearby household jobs.

## Included flows

- Worker and household dashboards
- Nearby jobs search and interest actions
- Wallet balance and transaction receipts
- Wallet PIN authorization before top-ups or family transfers
- Phone number + OTP login gate
- English, Hindi, Gujarati, and Marathi UI translations
- Help and support screen with SOS actions

## Run locally

This project is an Expo app. Use Node.js and pnpm.

```bash
pnpm install
pnpm --filter @workspace/kaamsetu run dev
```

For a standalone repository, you can run the app package directly:

```bash
cd artifacts/kaamsetu
pnpm install
pnpm exec expo start
```

## Demo credentials

The current prototype intentionally uses local demo validation:

- OTP: `123456`
- Wallet PIN: `1234`

The phone/OTP flow is a UI prototype and does not send real SMS messages. Before production use, connect it to a server-side OTP provider and never keep OTPs or wallet PINs in client-side code.

## GitHub upload

From the project root:

```bash
git init
git add .
git commit -m "Add KaamSetu Expo app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

If the GitHub repository already has a remote configured:

```bash
git add .
git commit -m "Update KaamSetu app"
git push
```

Do not commit `.env`, API keys, signing files, or generated `node_modules` folders.