import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useLanguage } from '@/context/LanguageContext';
import { LanguageMenu } from '@/components/LanguageMenu';

const questions = ['How do I post a job?', 'How do I add money?', 'Family transfer', 'Wallet PIN reset', 'Trust score'];

export default function HelpScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topInset = Math.max(insets.top + 14, 34);
  const { t } = useLanguage();
  const [message, setMessage] = useState('');
  const [conversation, setConversation] = useState<{ text: string; fromUser?: boolean }[]>([]);

  const ask = (question: string) => {
    setConversation((items) => [...items, { text: question, fromUser: true }, { text: responseFor(question) }]);
  };

  const sendMessage = () => {
    if (!message.trim()) return;
    ask(message.trim());
    setMessage('');
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 98 }}>
        <View style={[styles.header, { paddingTop: topInset }]}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>{t('weAreHere')}</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>{t('helpSupport')}</Text>
          </View>
          <View style={styles.headerActions}>
            <LanguageMenu />
            <View style={[styles.onlineBadge, { backgroundColor: '#E4F4EA' }]}>
              <View style={styles.onlineDot} />
              <Text style={styles.onlineText}>{t('online')}</Text>
            </View>
          </View>
        </View>

        <View style={styles.body}>
          <View style={[styles.parthCard, { backgroundColor: colors.indigo }]}>
            <View style={styles.parthAvatar}><Text style={styles.parthInitial}>P</Text></View>
            <View style={styles.parthCopy}>
              <Text style={styles.parthEyebrow}>CUSTOMER CARE LEAD</Text>
              <Text style={styles.parthName}>Parth is here to help</Text>
              <Text style={styles.parthSub}>Usually replies in under 2 minutes</Text>
            </View>
            <Feather name="headphones" size={24} color="#DCE5FF" />
          </View>

          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{t('whatHelp')}</Text>
          <View style={styles.chips}>
            {questions.map((question) => (
              <Pressable key={question} onPress={() => ask(question)} style={[styles.chip, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Text style={[styles.chipText, { color: colors.foreground }]}>{question}</Text>
              </Pressable>
            ))}
          </View>

          <View style={[styles.chatCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.chatHeader}>
              <View style={[styles.chatIcon, { backgroundColor: colors.accent }]}><Feather name="message-circle" size={17} color={colors.accentForeground} /></View>
              <View>
                <Text style={[styles.chatTitle, { color: colors.foreground }]}>KaamSetu assistant</Text>
                <Text style={[styles.chatSub, { color: colors.mutedForeground }]}>Quick answers in your language</Text>
              </View>
            </View>
            <View style={[styles.messageBubble, { backgroundColor: colors.secondary }]}>
              <Text style={[styles.messageText, { color: colors.foreground }]}>Namaste! I can help you with jobs, wallet, payments, and safety.</Text>
            </View>
            {conversation.map((item, index) => (
              <View key={`${item.text}-${index}`} style={[styles.messageBubble, item.fromUser ? { backgroundColor: colors.accent, alignSelf: 'flex-end' } : { backgroundColor: colors.secondary }]}>
                <Text style={[styles.messageText, { color: colors.foreground }]}>{item.text}</Text>
              </View>
            ))}
            <View style={[styles.messageInput, { borderColor: colors.input, backgroundColor: colors.background }]}>
              <TextInput value={message} onChangeText={setMessage} onSubmitEditing={sendMessage} placeholder="Ask anything..." placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground }]} />
              <Pressable onPress={sendMessage} style={[styles.sendButton, { backgroundColor: colors.primary }]}>
                <Feather name="arrow-up" size={17} color={colors.primaryForeground} />
              </Pressable>
            </View>
          </View>

          <Text style={[styles.sectionTitle, { color: colors.foreground, marginTop: 25 }]}>{t('contactCare')}</Text>
          <View style={styles.contactRow}>
            <ContactButton icon="phone" label={t('callParth')} sub="+91 84339 27633" onPress={() => Alert.alert('Calling Parth', '+91 84339 27633')} colors={colors} />
            <ContactButton icon="message-square" label={t('whatsapp')} sub="Chat with us" onPress={() => Alert.alert('WhatsApp support', 'Opening WhatsApp support chat')} colors={colors} />
          </View>
          <Pressable onPress={() => Alert.alert('Emergency SOS', 'Your family safety contact Meena will be alerted.')} style={[styles.sosButton, { backgroundColor: '#FBEAE6', borderColor: '#F2C8BF' }]}>
            <View style={styles.sosIcon}><Feather name="alert-circle" size={18} color="#B84E3C" /></View>
            <View style={styles.sosCopy}>
              <Text style={styles.sosTitle}>{t('emergencySos')}</Text>
              <Text style={styles.sosSub}>Alert your registered safety contact</Text>
            </View>
            <Feather name="chevron-right" size={17} color="#B84E3C" />
          </Pressable>
          <Text style={[styles.email, { color: colors.mutedForeground }]}>parth.care@kaamsetu.in · 1800-890-PARTH</Text>
        </View>
      </ScrollView>
    </View>
  );
}

function responseFor(question: string) {
  const normalized = question.toLowerCase();
  if (normalized.includes('post')) return 'Tap Household mode from your profile, then choose Post a job. Add the skill, budget, time, and location.';
  if (normalized.includes('money')) return 'Open the Wallet tab and tap Add money. Every top-up is protected by your 4-digit Wallet PIN.';
  if (normalized.includes('family')) return 'Open Wallet, tap Send to family, and confirm the amount with your secure PIN.';
  if (normalized.includes('pin')) return 'For a Wallet PIN reset, Parth can verify your phone number and help you securely.';
  if (normalized.includes('trust')) return 'Your Trust Score is based on positive ratings after completed jobs. A higher percentage means more trust.';
  return 'Thanks for reaching out. Parth will help you with that shortly.';
}

function ContactButton({ icon, label, sub, onPress, colors }: { icon: keyof typeof Feather.glyphMap; label: string; sub: string; onPress: () => void; colors: ReturnType<typeof useColors> }) {
  return (
    <Pressable onPress={onPress} style={[styles.contactButton, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[styles.contactIcon, { backgroundColor: colors.accent }]}><Feather name={icon} size={17} color={colors.accentForeground} /></View>
      <Text style={[styles.contactLabel, { color: colors.foreground }]}>{label}</Text>
      <Text style={[styles.contactSub, { color: colors.mutedForeground }]}>{sub}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 19, flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
  eyebrow: { fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 1.1, marginBottom: 5 },
  title: { fontSize: 27, fontFamily: 'Inter_700Bold', letterSpacing: -0.7 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  onlineBadge: { height: 31, borderRadius: 16, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 5 },
  onlineDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#2DA35A' },
  onlineText: { color: '#257A43', fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  body: { paddingHorizontal: 20 },
  parthCard: { minHeight: 94, borderRadius: 19, padding: 15, flexDirection: 'row', alignItems: 'center', gap: 11, marginBottom: 25 },
  parthAvatar: { width: 48, height: 48, borderRadius: 16, backgroundColor: '#F47A45', alignItems: 'center', justifyContent: 'center' },
  parthInitial: { color: '#FFFFFF', fontSize: 22, fontFamily: 'Inter_700Bold' },
  parthCopy: { flex: 1 },
  parthEyebrow: { color: '#DCE5FF', fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 0.8 },
  parthName: { color: '#FFFFFF', fontSize: 15, fontFamily: 'Inter_700Bold', marginTop: 4 },
  parthSub: { color: '#DCE5FF', fontSize: 10, fontFamily: 'Inter_400Regular', marginTop: 3 },
  sectionTitle: { fontSize: 17, fontFamily: 'Inter_700Bold', letterSpacing: -0.3 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12, marginBottom: 19 },
  chip: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8 },
  chipText: { fontSize: 10, fontFamily: 'Inter_600SemiBold' },
  chatCard: { borderWidth: 1, borderRadius: 18, padding: 14 },
  chatHeader: { flexDirection: 'row', alignItems: 'center', gap: 9, marginBottom: 14 },
  chatIcon: { width: 35, height: 35, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  chatTitle: { fontSize: 12, fontFamily: 'Inter_700Bold' },
  chatSub: { fontSize: 10, fontFamily: 'Inter_400Regular', marginTop: 2 },
  messageBubble: { maxWidth: '88%', borderRadius: 12, padding: 10, marginBottom: 7 },
  messageText: { fontSize: 11, lineHeight: 16, fontFamily: 'Inter_400Regular' },
  messageInput: { height: 42, borderWidth: 1, borderRadius: 11, paddingLeft: 10, flexDirection: 'row', alignItems: 'center', marginTop: 5 },
  input: { flex: 1, fontSize: 11, fontFamily: 'Inter_400Regular' },
  sendButton: { width: 32, height: 32, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginRight: 4 },
  contactRow: { flexDirection: 'row', gap: 10, marginTop: 12 },
  contactButton: { flex: 1, borderWidth: 1, borderRadius: 15, padding: 12, minHeight: 89 },
  contactIcon: { width: 31, height: 31, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  contactLabel: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  contactSub: { fontSize: 9, fontFamily: 'Inter_400Regular', marginTop: 3 },
  sosButton: { minHeight: 64, borderRadius: 15, borderWidth: 1, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 10 },
  sosIcon: { width: 34, height: 34, borderRadius: 11, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center' },
  sosCopy: { flex: 1 },
  sosTitle: { color: '#9E4234', fontSize: 11, fontFamily: 'Inter_700Bold' },
  sosSub: { color: '#B85B4A', fontSize: 9, fontFamily: 'Inter_400Regular', marginTop: 3 },
  email: { textAlign: 'center', fontSize: 10, fontFamily: 'Inter_400Regular', marginTop: 15 },
});