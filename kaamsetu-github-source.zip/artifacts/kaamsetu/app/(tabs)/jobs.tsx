import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { TranslationKey, useLanguage } from '@/context/LanguageContext';
import { LanguageMenu } from '@/components/LanguageMenu';

type Job = {
  id: string;
  title: string;
  titleKey?: TranslationKey;
  category: string;
  categoryKey?: TranslationKey;
  location: string;
  distance: string;
  pay: string;
  time: string;
  posted: string;
  interested?: boolean;
};

const jobs: Job[] = [
  { id: '1', title: '2BHK wall painting', titleKey: 'jobWallPainting', category: 'Painting', categoryKey: 'painting', location: 'Shivaji Nagar', distance: '1.8 km', pay: '₹1,200', time: 'Today · 9:00 AM', posted: '12 min ago' },
  { id: '2', title: 'Leaking kitchen tap', titleKey: 'jobKitchenTap', category: 'Plumbing', categoryKey: 'plumbing', location: 'Kothrud', distance: '3.2 km', pay: '₹500', time: 'Tomorrow · Flexible', posted: '28 min ago' },
  { id: '3', title: 'Ceiling fan installation', titleKey: 'jobFanInstallation', category: 'Electrical', categoryKey: 'electrical', location: 'Erandwane', distance: '4.6 km', pay: '₹700', time: 'Today · 2:00 PM', posted: '1 hr ago' },
  { id: '4', title: 'Move-out home cleaning', titleKey: 'jobMoveOutCleaning', category: 'Cleaning', categoryKey: 'cleaning', location: 'Deccan', distance: '5.1 km', pay: '₹900', time: 'Sat · 8:00 AM', posted: '2 hrs ago' },
];

export default function JobsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topInset = Math.max(insets.top + 14, 34);
  const { t, language } = useLanguage();
  const [search, setSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const [interested, setInterested] = useState<string[]>([]);
  const filters = ['All', 'Painting', 'Plumbing', 'Cleaning', 'Electrical'];
  const filterLabel = (filter: string) =>
    filter === 'All' ? t('all') : filter === 'Painting' ? t('painting') : filter === 'Plumbing' ? t('plumbing') : filter === 'Cleaning' ? t('cleaning') : t('electrical');

  const filteredJobs = useMemo(
    () =>
      jobs.filter((job) => {
        const matchesFilter = activeFilter === 'All' || job.category === activeFilter;
        const matchesSearch = `${job.titleKey ? t(job.titleKey) : job.title} ${job.location} ${job.categoryKey ? t(job.categoryKey) : job.category}`.toLowerCase().includes(search.toLowerCase());
        return matchesFilter && matchesSearch;
      }),
    [activeFilter, language, search, t],
  );

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 98 }}>
        <View style={[styles.header, { paddingTop: topInset }]}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>{t('discoverOpportunities')}</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>{t('nearbyJobs')}</Text>
          </View>
          <View style={styles.headerActions}>
            <LanguageMenu />
            <Pressable style={[styles.mapButton, { backgroundColor: colors.indigo }]}>
              <Feather name="map" size={16} color="#FFFFFF" />
              <Text style={styles.mapText}>{t('map')}</Text>
            </Pressable>
          </View>
        </View>

        <View style={styles.body}>
          <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name="search" size={18} color={colors.mutedForeground} />
            <TextInput
              value={search}
              onChangeText={setSearch}
              placeholder={t('searchJobs')}
              placeholderTextColor={colors.mutedForeground}
              style={[styles.searchInput, { color: colors.foreground }]}
            />
            <Feather name="sliders" size={17} color={colors.foreground} />
          </View>

          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterRow}>
            {filters.map((filter) => (
              <Pressable
                key={filter}
                onPress={() => setActiveFilter(filter)}
                style={[
                  styles.filterPill,
                  { backgroundColor: activeFilter === filter ? colors.primary : colors.card, borderColor: activeFilter === filter ? colors.primary : colors.border },
                ]}
              >
                <Text style={[styles.filterText, { color: activeFilter === filter ? colors.primaryForeground : colors.foreground }]}>{filterLabel(filter)}</Text>
              </Pressable>
            ))}
          </ScrollView>

          <View style={styles.summaryRow}>
            <Text style={[styles.summary, { color: colors.foreground }]}>{filteredJobs.length} {t('jobsNearYou')}</Text>
            <Pressable style={styles.sortButton}>
              <Feather name="sliders" size={13} color={colors.primary} />
              <Text style={[styles.sortText, { color: colors.primary }]}>{t('bestMatch')}</Text>
            </Pressable>
          </View>

          {filteredJobs.map((job) => {
            const hasInterest = interested.includes(job.id);
            return (
              <View key={job.id} style={[styles.jobCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={styles.jobHeader}>
                  <View style={[styles.category, { backgroundColor: colors.accent }]}>
                    <Text style={[styles.categoryText, { color: colors.accentForeground }]}>{job.categoryKey ? t(job.categoryKey) : job.category}</Text>
                  </View>
                  <Text style={[styles.posted, { color: colors.mutedForeground }]}>{job.posted}</Text>
                </View>
                <Text style={[styles.jobTitle, { color: colors.foreground }]}>{job.titleKey ? t(job.titleKey) : job.title}</Text>
                <View style={styles.detailLine}>
                  <Feather name="map-pin" size={14} color={colors.mutedForeground} />
                  <Text style={[styles.detailText, { color: colors.mutedForeground }]}>{job.location} · {job.distance}</Text>
                </View>
                <View style={styles.detailLine}>
                  <Feather name="clock" size={14} color={colors.mutedForeground} />
                  <Text style={[styles.detailText, { color: colors.mutedForeground }]}>{job.time}</Text>
                </View>
                <View style={[styles.jobFooter, { borderTopColor: colors.border }]}>
                  <Text style={[styles.pay, { color: colors.foreground }]}>{job.pay}<Text style={[styles.paySuffix, { color: colors.mutedForeground }]}> / {t('day')}</Text></Text>
                  <Pressable
                    onPress={() => setInterested((current) => hasInterest ? current.filter((id) => id !== job.id) : [...current, job.id])}
                    style={[styles.interestButton, { backgroundColor: hasInterest ? '#E4F4EA' : colors.primary }]}
                  >
                    <Feather name={hasInterest ? 'check' : 'send'} size={14} color={hasInterest ? '#257A43' : colors.primaryForeground} />
                    <Text style={[styles.interestText, { color: hasInterest ? '#257A43' : colors.primaryForeground }]}>{hasInterest ? t('interested') : t('interested')}</Text>
                  </Pressable>
                </View>
              </View>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 19, flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
  eyebrow: { fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 1.1, marginBottom: 5 },
  title: { fontSize: 27, fontFamily: 'Inter_700Bold', letterSpacing: -0.7 },
  mapButton: { height: 36, borderRadius: 11, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', gap: 6 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  mapText: { color: '#FFFFFF', fontSize: 11, fontFamily: 'Inter_700Bold' },
  body: { paddingHorizontal: 20 },
  searchBox: { height: 48, borderRadius: 13, borderWidth: 1, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center', gap: 9 },
  searchInput: { flex: 1, fontSize: 13, fontFamily: 'Inter_400Regular' },
  filterRow: { gap: 8, paddingVertical: 17 },
  filterPill: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8 },
  filterText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  summary: { fontSize: 14, fontFamily: 'Inter_700Bold' },
  sortButton: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  sortText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  jobCard: { borderWidth: 1, borderRadius: 17, padding: 15, marginBottom: 11 },
  jobHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  category: { borderRadius: 7, paddingHorizontal: 8, paddingVertical: 5 },
  categoryText: { fontSize: 10, fontFamily: 'Inter_700Bold' },
  posted: { fontSize: 10, fontFamily: 'Inter_500Medium' },
  jobTitle: { fontSize: 16, fontFamily: 'Inter_700Bold', marginBottom: 9 },
  detailLine: { flexDirection: 'row', alignItems: 'center', gap: 7, marginBottom: 6 },
  detailText: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  jobFooter: { borderTopWidth: 1, marginTop: 8, paddingTop: 11, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  pay: { fontSize: 15, fontFamily: 'Inter_700Bold' },
  paySuffix: { fontSize: 10, fontFamily: 'Inter_400Regular' },
  interestButton: { borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 5 },
  interestText: { fontSize: 10, fontFamily: 'Inter_700Bold' },
});