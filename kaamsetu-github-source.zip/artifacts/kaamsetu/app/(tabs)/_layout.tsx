import React from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { Feather } from '@expo/vector-icons';
import { Tabs } from 'expo-router';
import { useLanguage } from '@/context/LanguageContext';
function ClassicTabLayout() {
  const colors = useColors();
  const { t } = useLanguage();
  const isWeb = Platform.OS === 'web';
  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.mutedForeground,
        headerShown: false,
        tabBarStyle: {
          position: 'absolute',
          backgroundColor: colors.card,
          borderTopWidth: isWeb ? 1 : 0,
          borderTopColor: colors.border,
          elevation: 8,
          height: isWeb ? 84 : 72,
          paddingBottom: isWeb ? 20 : 10,
          paddingTop: 8,
        },
        tabBarBackground: () => (
          <View style={[StyleSheet.absoluteFill, { backgroundColor: colors.card }]} />
        ),
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: t('workerHome'),
          tabBarIcon: ({ color }) => <Feather name="home" size={21} color={color} />,
        }}
      />
      <Tabs.Screen
        name="jobs"
        options={{
          title: t('nearbyJobs'),
          tabBarIcon: ({ color }) => <Feather name="briefcase" size={21} color={color} />,
        }}
      />
      <Tabs.Screen
        name="wallet"
        options={{
          title: t('myWallet'),
          tabBarIcon: ({ color }) => <Feather name="credit-card" size={21} color={color} />,
        }}
      />
      <Tabs.Screen
        name="help"
        options={{
          title: t('helpSupport'),
          tabBarIcon: ({ color }) => <Feather name="message-circle" size={21} color={color} />,
        }}
      />
    </Tabs>
  );
}

export default function TabLayout() {
  return <ClassicTabLayout />;
}
