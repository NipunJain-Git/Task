import React, { useMemo, useState } from 'react';
import {
  Alert,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useColors } from '@/hooks/useColors';
import { TranslationKey, useLanguage } from '@/context/LanguageContext';
import { LanguageMenu } from '@/components/LanguageMenu';
import { WalletPinModal } from '@/components/WalletPinModal';

type Role = 'worker' | 'household';
type Job = {
  id: string;
  title: string;
  titleKey?: TranslationKey;
  category: string;
  categoryKey?: TranslationKey;
  location: string;
  distance: string;
  pay: string;
  time: string;
  posted: string;
  applicants: number;
  status?: 'open' | 'interested' | 'assigned';
};

const workerJobs: Job[] = [
  {
    id: '1',
    title: '2BHK wall painting',
    titleKey: 'jobWallPainting',
    category: 'Painting',
    categoryKey: 'painting',
    location: 'Shivaji Nagar',
    distance: '1.8 km',
    pay: '₹1,200',
    time: 'Today · 9:00 AM',
    posted: '12 min ago',
    applicants: 4,
  },
  {
    id: '2',
    title: 'Leaking kitchen tap',
    titleKey: 'jobKitchenTap',
    category: 'Plumbing',
    categoryKey: 'plumbing',
    location: 'Kothrud',
    distance: '3.2 km',
    pay: '₹500',
    time: 'Tomorrow · Flexible',
    posted: '28 min ago',
    applicants: 2,
  },
  {
    id: '3',
    title: 'Ceiling fan installation',
    titleKey: 'jobFanInstallation',
    category: 'Electrical',
    categoryKey: 'electrical',
    location: 'Erandwane',
    distance: '4.6 km',
    pay: '₹700',
    time: 'Today · 2:00 PM',
    posted: '1 hr ago',
    applicants: 7,
  },
];

const householdJobs: Job[] = [
  {
    id: 'h1',
    title: 'Paint bedroom walls',
    titleKey: 'jobPaintBedroom',
    category: 'Painting',
    categoryKey: 'painting',
    location: 'Aundh',
    distance: '2.1 km',
    pay: '₹1,500',
    time: 'Sat · 10:00 AM',
    posted: 'Active',
    applicants: 6,
    status: 'open',
  },
  {
    id: 'h2',
    title: 'Deep clean kitchen',
    titleKey: 'jobDeepCleanKitchen',
    category: 'Cleaning',
    categoryKey: 'cleaning',
    location: 'Baner',
    distance: '3.7 km',
    pay: '₹800',
    time: 'Sun · 9:00 AM',
    posted: '2 interested',
    applicants: 2,
    status: 'open',
  },
];

const skills = [
  { label: 'Painting', icon: 'edit-3' as const, tone: '#FCE2D5' },
  { label: 'Plumbing', icon: 'droplet' as const, tone: '#DDEAF8' },
  { label: 'Cleaning', icon: 'wind' as const, tone: '#E0F0E8' },
  { label: 'Electrical', icon: 'zap' as const, tone: '#FFF0C7' },
];

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topInset = Math.max(insets.top + 14, 34);
  const { t, language } = useLanguage();
  const [role, setRole] = useState<Role>('worker');
  const [available, setAvailable] = useState(true);
  const [jobs, setJobs] = useState<Job[]>(workerJobs);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [showProfile, setShowProfile] = useState(false);
  const [showPostJob, setShowPostJob] = useState(false);
  const [showWalletAction, setShowWalletAction] = useState<'add' | 'send' | null>(null);
  const [pinRequest, setPinRequest] = useState<{ amount: number; type: 'add' | 'send' } | null>(null);
  const [search, setSearch] = useState('');
  const [balance, setBalance] = useState(2840);
  const [toast, setToast] = useState('');

  const filteredJobs = useMemo(
    () =>
      jobs.filter((job) =>
        `${job.title} ${job.category} ${job.location}`
          .toLowerCase()
          .includes(search.toLowerCase()),
      ),
    [jobs, language, search, t],
  );

  const feedback = (message: string) => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => undefined);
    setToast(message);
    setTimeout(() => setToast(''), 2200);
  };

  const changeRole = (nextRole: Role) => {
    setRole(nextRole);
    setJobs(nextRole === 'worker' ? workerJobs : householdJobs);
    setShowProfile(false);
    feedback(nextRole === 'worker' ? 'Worker mode enabled' : 'Household mode enabled');
  };

  const expressInterest = (job: Job) => {
    setJobs((current) =>
      current.map((item) => (item.id === job.id ? { ...item, status: 'interested' } : item)),
    );
    setSelectedJob(null);
    feedback('Interest sent to the household');
  };

  const postJob = (job: Job) => {
    setJobs((current) => [job, ...current]);
    setShowPostJob(false);
    feedback('Your job is now live');
  };

  const moneyAction = (amount: number, type: 'add' | 'send') => {
    setBalance((current) => (type === 'add' ? current + amount : Math.max(0, current - amount)));
    setShowWalletAction(null);
    feedback(type === 'add' ? `₹${amount.toLocaleString('en-IN')} added securely` : 'Money sent to family');
  };

  const requestWalletPin = (amount: number, type: 'add' | 'send') => {
    setShowWalletAction(null);
    setPinRequest({ amount, type });
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 104 }}
      >
        <View style={[styles.header, { paddingTop: topInset }]}>
          <View style={styles.brandRow}>
            <View style={[styles.logo, { backgroundColor: colors.primary }]}>
              <Feather name="git-merge" size={20} color={colors.primaryForeground} />
            </View>
            <View>
              <Text style={[styles.brand, { color: colors.foreground }]}>KaamSetu</Text>
              <Text style={[styles.tagline, { color: colors.mutedForeground }]}>
                काम का भरोसेमंद पुल
              </Text>
            </View>
          </View>
          <View style={styles.headerActions}>
            <LanguageMenu />
            <Pressable
              onPress={() => setShowProfile(true)}
              style={[styles.avatar, { backgroundColor: colors.accent }]}
              testID="profile-button"
            >
              <Text style={[styles.avatarText, { color: colors.accentForeground }]}>RS</Text>
            </Pressable>
          </View>
        </View>

        <View style={styles.body}>
          <View style={styles.greetingRow}>
            <View>
              <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>
                {role === 'worker' ? t('workerHome') : t('householdHome')}
              </Text>
              <Text style={[styles.greeting, { color: colors.foreground }]}>Namaste, Ramesh</Text>
            </View>
            <Pressable
              onPress={() => setAvailable((value) => !value)}
              style={[
                styles.availability,
                {
                  backgroundColor: available ? '#E4F4EA' : colors.muted,
                  borderColor: available ? '#B9E2C7' : colors.border,
                },
              ]}
              testID="availability-toggle"
            >
              <View style={[styles.statusDot, { backgroundColor: available ? '#2DA35A' : colors.mutedForeground }]} />
              <Text style={[styles.availabilityText, { color: available ? '#257A43' : colors.mutedForeground }]}>
                {available ? t('available') : t('offline')}
              </Text>
            </Pressable>
          </View>

          {role === 'worker' ? (
            <>
              <View style={[styles.earningsCard, { backgroundColor: colors.primary }]}>
                <View style={styles.earningsTop}>
                  <View>
                    <Text style={[styles.cardOverline, { color: '#FFE5D7' }]}>{t('walletBalance')}</Text>
                    <Text style={[styles.balance, { color: colors.primaryForeground }]}>₹{balance.toLocaleString('en-IN')}</Text>
                  </View>
                  <View style={styles.walletIcon}>
                    <Feather name="shield" size={20} color="#FFF3ED" />
                  </View>
                </View>
                <View style={styles.earningsFooter}>
                    <Text style={[styles.verified, { color: '#FFF3ED' }]}>
                    <Feather name="check-circle" size={13} color="#FFF3ED" /> {t('pinProtected')}
                  </Text>
                  <Pressable onPress={() => setShowWalletAction('add')} style={styles.addMoneyButton}>
                    <Text style={[styles.addMoneyText, { color: colors.primary }]}>{t('addMoney')}</Text>
                    <Feather name="arrow-up-right" size={15} color={colors.primary} />
                  </Pressable>
                </View>
              </View>

              <View style={styles.sectionHeading}>
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{t('findWorkNearby')}</Text>
                <Text style={[styles.sectionMeta, { color: colors.primary }]}>{t('jobsToday')}</Text>
              </View>
              <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Feather name="search" size={18} color={colors.mutedForeground} />
                <TextInput
                  value={search}
                  onChangeText={setSearch}
                  placeholder={t('searchSkillLocation')}
                  placeholderTextColor={colors.mutedForeground}
                  style={[styles.searchInput, { color: colors.foreground }]}
                />
                <Pressable style={[styles.filterButton, { backgroundColor: colors.secondary }]}>
                  <Feather name="sliders" size={16} color={colors.foreground} />
                </Pressable>
              </View>

              <View style={styles.skillRow}>
                {skills.map((skill) => (
                  <Pressable
                    key={skill.label}
                    onPress={() => setSearch(skill.label)}
                    style={styles.skillItem}
                    testID={`skill-${skill.label}`}
                  >
                    <View style={[styles.skillIcon, { backgroundColor: skill.tone }]}>
                      <Feather name={skill.icon} size={18} color={colors.foreground} />
                    </View>
                    <Text style={[styles.skillLabel, { color: colors.mutedForeground }]}>
                      {skill.label === 'Painting' ? t('painting') : skill.label === 'Plumbing' ? t('plumbing') : skill.label === 'Cleaning' ? t('cleaning') : t('electrical')}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </>
          ) : (
            <View style={[styles.householdHero, { backgroundColor: colors.indigo }]}>
              <View style={styles.heroCopy}>
                <Text style={[styles.cardOverline, { color: '#CDD7F2' }]}>HIRE WITH CONFIDENCE</Text>
                <Text style={[styles.heroTitle, { color: '#FFFFFF' }]}>The right help is closer than you think.</Text>
                <Text style={[styles.heroSub, { color: '#CDD7F2' }]}>Post a one-day job and meet trusted local workers.</Text>
                <Pressable onPress={() => setShowPostJob(true)} style={styles.heroButton}>
                  <Feather name="plus" size={17} color={colors.indigo} />
                  <Text style={[styles.heroButtonText, { color: colors.indigo }]}>Post a job</Text>
                </Pressable>
              </View>
              <Feather name="home" size={86} color="rgba(255,255,255,0.12)" style={styles.heroIcon} />
            </View>
          )}

          <View style={styles.sectionHeading}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              {role === 'worker' ? t('recommended') : t('viewAll')}
            </Text>
            <Pressable onPress={() => setSearch('')}>
              <Text style={[styles.sectionMeta, { color: colors.primary }]}>{t('viewAll')}</Text>
            </Pressable>
          </View>

          {filteredJobs.length === 0 ? (
            <View style={[styles.emptyState, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Feather name="search" size={28} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No jobs found</Text>
              <Text style={[styles.emptyCopy, { color: colors.mutedForeground }]}>Try another skill or location.</Text>
            </View>
          ) : (
            filteredJobs.map((job) => (
              <Pressable
                key={job.id}
                onPress={() => setSelectedJob(job)}
                style={({ pressed }) => [
                  styles.jobCard,
                  { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.88 : 1 },
                ]}
                testID={`job-${job.id}`}
              >
                <View style={styles.jobTop}>
                  <View style={[styles.categoryPill, { backgroundColor: colors.accent }]}>
                    <Text style={[styles.categoryText, { color: colors.accentForeground }]}>{job.categoryKey ? t(job.categoryKey) : job.category}</Text>
                  </View>
                  {job.status === 'interested' ? (
                    <View style={[styles.interestBadge, { backgroundColor: '#E4F4EA' }]}>
                      <Feather name="check" size={12} color="#2D8A4B" />
                        <Text style={styles.interestText}>{t('interested')}</Text>
                    </View>
                  ) : (
                    <Text style={[styles.posted, { color: colors.mutedForeground }]}>{job.posted}</Text>
                  )}
                </View>
                <Text style={[styles.jobTitle, { color: colors.foreground }]}>{job.titleKey ? t(job.titleKey) : job.title}</Text>
                <View style={styles.jobDetails}>
                  <View style={styles.detailItem}>
                    <Feather name="map-pin" size={14} color={colors.mutedForeground} />
                    <Text style={[styles.detailText, { color: colors.mutedForeground }]}>{job.location} · {job.distance}</Text>
                  </View>
                  <View style={styles.detailItem}>
                    <Feather name="clock" size={14} color={colors.mutedForeground} />
                    <Text style={[styles.detailText, { color: colors.mutedForeground }]}>{job.time}</Text>
                  </View>
                </View>
                <View style={[styles.jobBottom, { borderTopColor: colors.border }]}>
                  <Text style={[styles.pay, { color: colors.foreground }]}>{job.pay}<Text style={[styles.paySuffix, { color: colors.mutedForeground }]}> / {t('day')}</Text></Text>
                  <View style={styles.applicants}>
                    <Feather name="users" size={14} color={colors.mutedForeground} />
                    <Text style={[styles.detailText, { color: colors.mutedForeground }]}>{job.applicants} interested</Text>
                  </View>
                  <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
                </View>
              </Pressable>
            ))
          )}

          <View style={styles.trustBanner}>
            <View style={[styles.trustIcon, { backgroundColor: colors.indigo }]}>
              <Feather name="heart" size={18} color="#FFFFFF" />
            </View>
            <View style={styles.trustCopy}>
              <Text style={[styles.trustTitle, { color: colors.foreground }]}>Your safety comes first</Text>
              <Text style={[styles.trustText, { color: colors.mutedForeground }]}>Family alerts and secure payouts are always on.</Text>
            </View>
            <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
          </View>
        </View>
      </ScrollView>

      {toast ? (
        <View style={[styles.toast, { backgroundColor: colors.indigo }]}>
          <Feather name="check-circle" size={17} color="#FFFFFF" />
          <Text style={styles.toastText}>{toast}</Text>
        </View>
      ) : null}

      <Modal visible={Boolean(selectedJob)} animationType="slide" transparent onRequestClose={() => setSelectedJob(null)}>
        {selectedJob ? (
          <View style={[styles.modalBackdrop, { backgroundColor: 'rgba(24,35,58,0.4)' }]}>
            <View style={[styles.detailSheet, { backgroundColor: colors.background, paddingBottom: insets.bottom + 18 }]}>
              <View style={styles.sheetHandle} />
              <View style={styles.sheetHeader}>
                <View style={[styles.categoryPill, { backgroundColor: colors.accent }]}>
                  <Text style={[styles.categoryText, { color: colors.accentForeground }]}>
                    {selectedJob.categoryKey ? t(selectedJob.categoryKey) : selectedJob.category}
                  </Text>
                </View>
                <Pressable onPress={() => setSelectedJob(null)} style={styles.closeButton}>
                  <Feather name="x" size={19} color={colors.foreground} />
                </Pressable>
              </View>
               <Text style={[styles.sheetTitle, { color: colors.foreground }]}>{selectedJob.titleKey ? t(selectedJob.titleKey) : selectedJob.title}</Text>
               <Text style={[styles.sheetDescription, { color: colors.mutedForeground }]}>
                 {t('jobDescription').replace('{category}', selectedJob.categoryKey ? t(selectedJob.categoryKey).toLowerCase() : selectedJob.category.toLowerCase())}
               </Text>
              <View style={[styles.infoGrid, { backgroundColor: colors.card, borderColor: colors.border }]}>
                 <InfoCell icon="map-pin" label={t('location')} value={`${selectedJob.location}\n${selectedJob.distance} away`} colors={colors} />
                 <InfoCell icon="clock" label={t('when')} value={selectedJob.time} colors={colors} />
                 <InfoCell icon="credit-card" label={t('budget')} value={`${selectedJob.pay} / ${t('day')}`} colors={colors} />
                 <InfoCell icon="thumbs-up" label={t('household')} value={`96% ${t('positive')}`} colors={colors} />
              </View>
              {role === 'worker' ? (
                <Pressable
                  onPress={() => selectedJob.status === 'interested' ? setSelectedJob(null) : expressInterest(selectedJob)}
                  style={[styles.primaryButton, { backgroundColor: colors.primary }]}
                  testID="interest-button"
                >
                  <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>
                     {selectedJob.status === 'interested' ? t('interestSent') : t('imInterested')}
                  </Text>
                  <Feather name={selectedJob.status === 'interested' ? 'check' : 'arrow-right'} size={17} color={colors.primaryForeground} />
                </Pressable>
              ) : (
                <Pressable
                  onPress={() => {
                    setSelectedJob(null);
                    feedback('Worker list opened');
                  }}
                  style={[styles.primaryButton, { backgroundColor: colors.indigo }]}
                >
                   <Text style={styles.primaryButtonText}>{t('viewInterestedWorkers')}</Text>
                  <Feather name="users" size={17} color="#FFFFFF" />
                </Pressable>
              )}
            </View>
          </View>
        ) : null}
      </Modal>

      <Modal visible={showProfile} animationType="slide" transparent onRequestClose={() => setShowProfile(false)}>
        <View style={[styles.modalBackdrop, { backgroundColor: 'rgba(24,35,58,0.4)' }]}>
          <View style={[styles.profileSheet, { backgroundColor: colors.background, paddingBottom: insets.bottom + 18 }]}>
            <View style={styles.sheetHandle} />
            <View style={styles.profileIdentity}>
              <View style={[styles.profileAvatar, { backgroundColor: colors.accent }]}>
                <Text style={[styles.profileAvatarText, { color: colors.accentForeground }]}>RS</Text>
              </View>
              <View>
                <Text style={[styles.sheetTitle, { color: colors.foreground }]}>Ramesh Sharma</Text>
                <Text style={[styles.sheetDescription, { color: colors.mutedForeground }]}>Pune · Member since 2025</Text>
              </View>
            </View>
            <View style={[styles.trustProfile, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View>
                <Text style={[styles.cardOverline, { color: colors.mutedForeground }]}>TRUST SCORE</Text>
                <Text style={[styles.trustScore, { color: colors.foreground }]}>98% <Text style={[styles.trustScoreSuffix, { color: colors.mutedForeground }]}>positive</Text></Text>
              </View>
              <View style={styles.scorePills}>
                <Text style={styles.upPill}>↑ 48</Text>
                <Text style={styles.downPill}>↓ 1</Text>
              </View>
            </View>
            <Text style={[styles.menuLabel, { color: colors.mutedForeground }]}>USE KAAMSETU AS</Text>
            <RoleButton role="worker" active={role === 'worker'} label="Worker" sub="Find nearby work" icon="briefcase" onPress={() => changeRole('worker')} colors={colors} />
            <RoleButton role="household" active={role === 'household'} label="Household" sub="Hire trusted help" icon="home" onPress={() => changeRole('household')} colors={colors} />
            <Pressable onPress={() => feedback('Customer care is ready to help')} style={[styles.supportLink, { borderTopColor: colors.border }]}>
              <Feather name="headphones" size={18} color={colors.primary} />
              <Text style={[styles.supportLinkText, { color: colors.foreground }]}>Contact customer care</Text>
              <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
            </Pressable>
          </View>
        </View>
      </Modal>

      <Modal visible={Boolean(showWalletAction)} animationType="slide" transparent onRequestClose={() => setShowWalletAction(null)}>
        <View style={[styles.modalBackdrop, { backgroundColor: 'rgba(24,35,58,0.4)' }]}>
          <View style={[styles.actionSheet, { backgroundColor: colors.background, paddingBottom: insets.bottom + 18 }]}>
            <View style={styles.sheetHandle} />
            <Text style={[styles.sheetTitle, { color: colors.foreground }]}>{showWalletAction === 'add' ? 'Add money' : 'Send to family'}</Text>
            <Text style={[styles.sheetDescription, { color: colors.mutedForeground }]}>
              {showWalletAction === 'add' ? 'Choose a secure way to add money to your KaamSetu Wallet.' : 'Send money instantly to Meena (Spouse), your registered family contact.'}
            </Text>
            <AmountButton label={showWalletAction === 'add' ? 'Add ₹500' : 'Send ₹500'} icon={showWalletAction === 'add' ? 'plus-circle' : 'send'} onPress={() => requestWalletPin(500, showWalletAction ?? 'add')} colors={colors} />
            <AmountButton label={showWalletAction === 'add' ? 'Add ₹1,000' : 'Send ₹1,000'} icon={showWalletAction === 'add' ? 'plus-circle' : 'send'} onPress={() => requestWalletPin(1000, showWalletAction ?? 'add')} colors={colors} />
            <Pressable onPress={() => setShowWalletAction(null)} style={styles.cancelButton}>
              <Text style={[styles.cancelText, { color: colors.mutedForeground }]}>Cancel</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      <WalletPinModal
        visible={Boolean(pinRequest)}
        amount={pinRequest?.amount ?? 0}
        actionLabel={pinRequest?.type === 'send' ? 'sending' : 'adding'}
        onClose={() => setPinRequest(null)}
        onSuccess={() => {
          if (pinRequest) moneyAction(pinRequest.amount, pinRequest.type);
          setPinRequest(null);
        }}
      />

      <Modal visible={showPostJob} animationType="slide" transparent onRequestClose={() => setShowPostJob(false)}>
        <View style={[styles.modalBackdrop, { backgroundColor: 'rgba(24,35,58,0.4)' }]}>
          <PostJobSheet colors={colors} insetsBottom={insets.bottom} onClose={() => setShowPostJob(false)} onPost={postJob} />
        </View>
      </Modal>

    </View>
  );
}

function InfoCell({ icon, label, value, colors }: { icon: keyof typeof Feather.glyphMap; label: string; value: string; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={styles.infoCell}>
      <Feather name={icon} size={16} color={colors.primary} />
      <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.infoValue, { color: colors.foreground }]}>{value}</Text>
    </View>
  );
}

function RoleButton({ role, active, label, sub, icon, onPress, colors }: { role: Role; active: boolean; label: string; sub: string; icon: keyof typeof Feather.glyphMap; onPress: () => void; colors: ReturnType<typeof useColors> }) {
  return (
    <Pressable onPress={onPress} style={[styles.roleButton, { backgroundColor: active ? colors.accent : colors.card, borderColor: active ? colors.primary : colors.border }]}>
      <View style={[styles.roleIcon, { backgroundColor: active ? colors.primary : colors.secondary }]}>
        <Feather name={icon} size={18} color={active ? colors.primaryForeground : colors.foreground} />
      </View>
      <View style={styles.roleCopy}>
        <Text style={[styles.roleLabel, { color: colors.foreground }]}>{label}</Text>
        <Text style={[styles.roleSub, { color: colors.mutedForeground }]}>{sub}</Text>
      </View>
      <View style={[styles.radio, { borderColor: active ? colors.primary : colors.input }]}>
        {active ? <View style={[styles.radioDot, { backgroundColor: colors.primary }]} /> : null}
      </View>
    </Pressable>
  );
}

function AmountButton({ label, icon, onPress, colors }: { label: string; icon: keyof typeof Feather.glyphMap; onPress: () => void; colors: ReturnType<typeof useColors> }) {
  return (
    <Pressable onPress={onPress} style={[styles.amountButton, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Feather name={icon} size={19} color={colors.primary} />
      <Text style={[styles.amountButtonText, { color: colors.foreground }]}>{label}</Text>
      <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
    </Pressable>
  );
}

function PostJobSheet({ colors, insetsBottom, onClose, onPost }: { colors: ReturnType<typeof useColors>; insetsBottom: number; onClose: () => void; onPost: (job: Job) => void }) {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Painting');
  const [budget, setBudget] = useState('1000');
  const canPost = title.trim().length > 2;
  return (
    <View style={[styles.postSheet, { backgroundColor: colors.background, paddingBottom: insetsBottom + 18 }]}>
      <View style={styles.sheetHandle} />
      <View style={styles.sheetHeader}>
        <View>
          <Text style={[styles.sheetTitle, { color: colors.foreground }]}>Post a one-day job</Text>
          <Text style={[styles.sheetDescription, { color: colors.mutedForeground }]}>Nearby workers will see it right away.</Text>
        </View>
        <Pressable onPress={onClose} style={styles.closeButton}><Feather name="x" size={19} color={colors.foreground} /></Pressable>
      </View>
      <Text style={[styles.inputLabel, { color: colors.foreground }]}>What help do you need?</Text>
      <TextInput value={title} onChangeText={setTitle} placeholder="e.g. Paint my bedroom" placeholderTextColor={colors.mutedForeground} style={[styles.formInput, { borderColor: colors.input, backgroundColor: colors.card, color: colors.foreground }]} />
      <Text style={[styles.inputLabel, { color: colors.foreground }]}>Skill</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoryChoices}>
        {['Painting', 'Plumbing', 'Cleaning', 'Electrical'].map((item) => (
          <Pressable key={item} onPress={() => setCategory(item)} style={[styles.categoryChoice, { backgroundColor: category === item ? colors.accent : colors.card, borderColor: category === item ? colors.primary : colors.border }]}>
            <Text style={[styles.categoryChoiceText, { color: category === item ? colors.accentForeground : colors.foreground }]}>{item}</Text>
          </Pressable>
        ))}
      </ScrollView>
      <Text style={[styles.inputLabel, { color: colors.foreground }]}>Daily budget</Text>
      <View style={[styles.formInputRow, { borderColor: colors.input, backgroundColor: colors.card }]}>
        <Text style={[styles.rupee, { color: colors.mutedForeground }]}>₹</Text>
        <TextInput value={budget} onChangeText={setBudget} keyboardType="number-pad" style={[styles.budgetInput, { color: colors.foreground }]} />
        <Text style={[styles.budgetHint, { color: colors.mutedForeground }]}>negotiable</Text>
      </View>
      <Pressable disabled={!canPost} onPress={() => onPost({ id: `new-${Date.now()}`, title: title.trim(), category, location: 'Your location', distance: 'Nearby', pay: `₹${budget}`, time: 'Choose a time', posted: 'Just now', applicants: 0, status: 'open' })} style={[styles.primaryButton, { backgroundColor: canPost ? colors.primary : colors.input, marginTop: 12 }]}>
        <Text style={[styles.primaryButtonText, { color: canPost ? colors.primaryForeground : colors.mutedForeground }]}>Publish job</Text>
        <Feather name="arrow-right" size={17} color={canPost ? colors.primaryForeground : colors.mutedForeground} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 18, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logo: { width: 39, height: 39, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  brand: { fontSize: 21, fontFamily: 'Inter_700Bold', letterSpacing: -0.5 },
  tagline: { fontSize: 10, fontFamily: 'Inter_500Medium', marginTop: 1 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  langButton: { height: 34, paddingHorizontal: 9, borderRadius: 10, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 4 },
  langText: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  avatar: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  body: { paddingHorizontal: 20 },
  greetingRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 17 },
  eyebrow: { fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 1.2, marginBottom: 5 },
  greeting: { fontSize: 25, fontFamily: 'Inter_700Bold', letterSpacing: -0.7 },
  availability: { paddingHorizontal: 10, height: 31, borderRadius: 16, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 5 },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  availabilityText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  earningsCard: { borderRadius: 20, padding: 18, marginBottom: 25 },
  earningsTop: { flexDirection: 'row', justifyContent: 'space-between' },
  cardOverline: { fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 1.1 },
  balance: { fontSize: 32, fontFamily: 'Inter_700Bold', letterSpacing: -1, marginTop: 6 },
  walletIcon: { width: 40, height: 40, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  earningsFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 21 },
  verified: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  addMoneyButton: { backgroundColor: '#FFFFFF', borderRadius: 11, paddingHorizontal: 11, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 5 },
  addMoneyText: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  sectionHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  sectionTitle: { fontSize: 17, fontFamily: 'Inter_700Bold', letterSpacing: -0.3 },
  sectionMeta: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  searchBox: { height: 48, borderRadius: 13, borderWidth: 1, paddingLeft: 14, flexDirection: 'row', alignItems: 'center', marginBottom: 17 },
  searchInput: { flex: 1, fontSize: 13, fontFamily: 'Inter_400Regular', paddingHorizontal: 9 },
  filterButton: { height: 34, width: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginRight: 7 },
  skillRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 28 },
  skillItem: { alignItems: 'center', width: 68, gap: 7 },
  skillIcon: { width: 50, height: 50, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  skillLabel: { fontSize: 10, fontFamily: 'Inter_500Medium' },
  jobCard: { borderWidth: 1, borderRadius: 17, padding: 15, marginBottom: 11 },
  jobTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  categoryPill: { borderRadius: 7, paddingHorizontal: 8, paddingVertical: 5 },
  categoryText: { fontSize: 10, fontFamily: 'Inter_700Bold' },
  posted: { fontSize: 10, fontFamily: 'Inter_500Medium' },
  interestBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 7, paddingVertical: 5, borderRadius: 7 },
  interestText: { color: '#2D8A4B', fontSize: 10, fontFamily: 'Inter_700Bold' },
  jobTitle: { fontSize: 16, fontFamily: 'Inter_700Bold', marginBottom: 10 },
  jobDetails: { gap: 6, marginBottom: 14 },
  detailItem: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  detailText: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  jobBottom: { borderTopWidth: 1, paddingTop: 11, flexDirection: 'row', alignItems: 'center', gap: 11 },
  pay: { fontSize: 15, fontFamily: 'Inter_700Bold' },
  paySuffix: { fontSize: 10, fontFamily: 'Inter_400Regular' },
  applicants: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 5 },
  householdHero: { minHeight: 190, borderRadius: 20, padding: 19, marginBottom: 25, overflow: 'hidden' },
  heroCopy: { width: '72%', zIndex: 1 },
  heroTitle: { fontSize: 23, lineHeight: 28, fontFamily: 'Inter_700Bold', letterSpacing: -0.6, marginTop: 6 },
  heroSub: { fontSize: 12, lineHeight: 18, fontFamily: 'Inter_400Regular', marginTop: 7 },
  heroButton: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#FFFFFF', borderRadius: 11, paddingHorizontal: 12, paddingVertical: 9, marginTop: 14 },
  heroButtonText: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  heroIcon: { position: 'absolute', right: -6, bottom: 18, transform: [{ rotate: '-12deg' }] },
  emptyState: { borderWidth: 1, borderRadius: 17, alignItems: 'center', padding: 28, marginBottom: 15 },
  emptyTitle: { fontSize: 15, fontFamily: 'Inter_700Bold', marginTop: 10 },
  emptyCopy: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 4 },
  trustBanner: { flexDirection: 'row', alignItems: 'center', paddingVertical: 19, gap: 11 },
  trustIcon: { width: 37, height: 37, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  trustCopy: { flex: 1 },
  trustTitle: { fontSize: 12, fontFamily: 'Inter_700Bold' },
  trustText: { fontSize: 10, fontFamily: 'Inter_400Regular', marginTop: 3 },
  toast: { position: 'absolute', alignSelf: 'center', bottom: 93, flexDirection: 'row', alignItems: 'center', gap: 8, borderRadius: 13, paddingHorizontal: 15, paddingVertical: 12 },
  toastText: { color: '#FFFFFF', fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  modalBackdrop: { flex: 1, justifyContent: 'flex-end' },
  detailSheet: { borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingHorizontal: 20, paddingTop: 10 },
  sheetHandle: { width: 36, height: 4, borderRadius: 2, backgroundColor: '#D4D5D8', alignSelf: 'center', marginBottom: 18 },
  sheetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  closeButton: { width: 34, height: 34, borderRadius: 17, backgroundColor: 'rgba(128,128,128,0.10)', alignItems: 'center', justifyContent: 'center' },
  sheetTitle: { fontSize: 23, fontFamily: 'Inter_700Bold', letterSpacing: -0.5 },
  sheetDescription: { fontSize: 12, lineHeight: 18, fontFamily: 'Inter_400Regular', marginTop: 6 },
  infoGrid: { borderWidth: 1, borderRadius: 17, flexDirection: 'row', flexWrap: 'wrap', padding: 5, marginTop: 19, marginBottom: 18 },
  infoCell: { width: '50%', padding: 11, minHeight: 79 },
  infoLabel: { fontSize: 10, fontFamily: 'Inter_500Medium', marginTop: 6 },
  infoValue: { fontSize: 12, lineHeight: 17, fontFamily: 'Inter_700Bold', marginTop: 3 },
  primaryButton: { height: 52, borderRadius: 15, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  primaryButtonText: { fontSize: 14, fontFamily: 'Inter_700Bold' },
  profileSheet: { borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingHorizontal: 20, paddingTop: 10 },
  profileIdentity: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 18 },
  profileAvatar: { width: 54, height: 54, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  profileAvatarText: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  trustProfile: { borderWidth: 1, borderRadius: 17, padding: 15, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22 },
  trustScore: { fontSize: 23, fontFamily: 'Inter_700Bold', marginTop: 4 },
  trustScoreSuffix: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  scorePills: { flexDirection: 'row', gap: 7 },
  upPill: { color: '#257A43', backgroundColor: '#E4F4EA', paddingHorizontal: 8, paddingVertical: 6, borderRadius: 7, fontSize: 11, fontFamily: 'Inter_700Bold' },
  downPill: { color: '#9A5B50', backgroundColor: '#FBEAE6', paddingHorizontal: 8, paddingVertical: 6, borderRadius: 7, fontSize: 11, fontFamily: 'Inter_700Bold' },
  menuLabel: { fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 1, marginBottom: 9 },
  roleButton: { height: 62, borderWidth: 1, borderRadius: 15, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', marginBottom: 9 },
  roleIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  roleCopy: { flex: 1, marginLeft: 10 },
  roleLabel: { fontSize: 13, fontFamily: 'Inter_700Bold' },
  roleSub: { fontSize: 10, fontFamily: 'Inter_400Regular', marginTop: 3 },
  radio: { width: 20, height: 20, borderRadius: 10, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  radioDot: { width: 10, height: 10, borderRadius: 5 },
  supportLink: { borderTopWidth: 1, marginTop: 8, paddingTop: 17, flexDirection: 'row', alignItems: 'center', gap: 10 },
  supportLinkText: { flex: 1, fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  actionSheet: { borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingHorizontal: 20, paddingTop: 10 },
  amountButton: { borderWidth: 1, borderRadius: 14, height: 54, paddingHorizontal: 15, flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 11 },
  amountButtonText: { flex: 1, fontSize: 13, fontFamily: 'Inter_700Bold' },
  cancelButton: { height: 46, alignItems: 'center', justifyContent: 'center', marginTop: 7 },
  cancelText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  postSheet: { borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingHorizontal: 20, paddingTop: 10 },
  inputLabel: { fontSize: 12, fontFamily: 'Inter_700Bold', marginTop: 18, marginBottom: 7 },
  formInput: { height: 48, borderWidth: 1, borderRadius: 12, paddingHorizontal: 13, fontSize: 13, fontFamily: 'Inter_400Regular' },
  categoryChoices: { gap: 8 },
  categoryChoice: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 11, paddingVertical: 9 },
  categoryChoiceText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  formInputRow: { height: 48, borderWidth: 1, borderRadius: 12, paddingHorizontal: 13, flexDirection: 'row', alignItems: 'center' },
  rupee: { fontSize: 15, fontFamily: 'Inter_700Bold' },
  budgetInput: { flex: 1, fontSize: 13, fontFamily: 'Inter_600SemiBold', paddingHorizontal: 8 },
  budgetHint: { fontSize: 10, fontFamily: 'Inter_400Regular' },
});