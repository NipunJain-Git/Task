import React, { createContext, ReactNode, useContext, useMemo, useState } from 'react';

export type Language = 'English' | 'हिंदी' | 'ગુજરાતી' | 'मराठी';

export type TranslationKey =
  | 'workerHome'
  | 'householdHome'
  | 'available'
  | 'offline'
  | 'walletBalance'
  | 'pinProtected'
  | 'addMoney'
  | 'findWorkNearby'
  | 'jobsToday'
  | 'searchSkillLocation'
  | 'painting'
  | 'plumbing'
  | 'cleaning'
  | 'electrical'
  | 'recommended'
  | 'viewAll'
  | 'interested'
  | 'nearbyJobs'
  | 'discoverOpportunities'
  | 'map'
  | 'searchJobs'
  | 'all'
  | 'bestMatch'
  | 'jobsNearYou'
  | 'myWallet'
  | 'safeAndSimple'
  | 'pinOn'
  | 'sendToFamily'
  | 'familySafety'
  | 'transactionReceipts'
  | 'credit'
  | 'debit'
  | 'helpSupport'
  | 'weAreHere'
  | 'online'
  | 'whatHelp'
  | 'contactCare'
  | 'callParth'
  | 'whatsapp'
  | 'emergencySos'
  | 'jobWallPainting'
  | 'jobKitchenTap'
  | 'jobFanInstallation'
  | 'jobMoveOutCleaning'
  | 'jobPaintBedroom'
  | 'jobDeepCleanKitchen'
  | 'jobDescription'
  | 'location'
  | 'when'
  | 'budget'
  | 'household'
  | 'positive'
  | 'day'
  | 'interestSent'
  | 'imInterested'
  | 'viewInterestedWorkers'
  | 'noJobsFound'
  | 'tryAnother'
  | 'safetyFirst'
  | 'familyAlerts';

const translations: Record<Language, Record<TranslationKey, string>> = {
  English: {
    workerHome: 'WORKER HOME', householdHome: 'HOUSEHOLD HOME', available: 'Available', offline: 'Offline',
    walletBalance: 'WALLET BALANCE', pinProtected: 'PIN protected', addMoney: 'Add money',
    findWorkNearby: 'Find work nearby', jobsToday: '3 jobs today', searchSkillLocation: 'Search by skill or location',
    painting: 'Painting', plumbing: 'Plumbing', cleaning: 'Cleaning', electrical: 'Electrical',
    recommended: 'Recommended for you', viewAll: 'View all', interested: 'Interested',
    nearbyJobs: 'Nearby jobs', discoverOpportunities: 'DISCOVER OPPORTUNITIES', map: 'Map', searchJobs: 'Search jobs, skills or areas',
    all: 'All', bestMatch: 'Best match', jobsNearYou: 'jobs near you',
    myWallet: 'My wallet', safeAndSimple: 'SAFE AND SIMPLE', pinOn: 'PIN on', sendToFamily: 'Send to family',
    familySafety: 'Family safety link', transactionReceipts: 'Transaction receipts', credit: 'Credit', debit: 'Debit',
    helpSupport: 'Help & support', weAreHere: 'WE ARE HERE FOR YOU', online: 'Online', whatHelp: 'What can we help with?',
    contactCare: 'Contact customer care', callParth: 'Call Parth', whatsapp: 'WhatsApp', emergencySos: 'Emergency SOS to family',
    jobWallPainting: '2BHK wall painting', jobKitchenTap: 'Leaking kitchen tap', jobFanInstallation: 'Ceiling fan installation',
    jobMoveOutCleaning: 'Move-out home cleaning', jobPaintBedroom: 'Paint bedroom walls', jobDeepCleanKitchen: 'Deep clean kitchen',
    jobDescription: 'A local household needs a reliable {category} professional. Bring your own basic tools and arrive on time.',
    location: 'Location', when: 'When', budget: 'Budget', household: 'Household', positive: 'positive', day: 'day',
    interestSent: 'Interest sent', imInterested: "I'm interested", viewInterestedWorkers: 'View interested workers',
    noJobsFound: 'No jobs found', tryAnother: 'Try another skill or location.', safetyFirst: 'Your safety comes first',
    familyAlerts: 'Family alerts and secure payouts are always on.',
  },
  'हिंदी': {
    workerHome: 'कामगार होम', householdHome: 'परिवार होम', available: 'उपलब्ध', offline: 'ऑफलाइन',
    walletBalance: 'वॉलेट बैलेंस', pinProtected: 'पिन सुरक्षित', addMoney: 'पैसे जोड़ें',
    findWorkNearby: 'पास में काम खोजें', jobsToday: 'आज 3 काम', searchSkillLocation: 'कौशल या जगह से खोजें',
    painting: 'पेंटिंग', plumbing: 'प्लंबिंग', cleaning: 'सफाई', electrical: 'इलेक्ट्रिकल',
    recommended: 'आपके लिए काम', viewAll: 'सभी देखें', interested: 'रुचि भेजी',
    nearbyJobs: 'पास के काम', discoverOpportunities: 'नए अवसर खोजें', map: 'नक्शा', searchJobs: 'काम, कौशल या क्षेत्र खोजें',
    all: 'सभी', bestMatch: 'सबसे अच्छा मिलान', jobsNearYou: 'पास के काम',
    myWallet: 'मेरा वॉलेट', safeAndSimple: 'सुरक्षित और आसान', pinOn: 'पिन चालू', sendToFamily: 'परिवार को भेजें',
    familySafety: 'परिवार सुरक्षा लिंक', transactionReceipts: 'लेन-देन रसीदें', credit: 'जमा', debit: 'खर्च',
    helpSupport: 'मदद और सहायता', weAreHere: 'हम आपकी मदद के लिए हैं', online: 'ऑनलाइन', whatHelp: 'हम आपकी कैसे मदद करें?',
    contactCare: 'ग्राहक सहायता', callParth: 'पार्थ को कॉल करें', whatsapp: 'व्हाट्सऐप', emergencySos: 'परिवार को आपात SOS',
    jobWallPainting: '2BHK दीवार पेंटिंग', jobKitchenTap: 'रसोई का नल लीक', jobFanInstallation: 'सीलिंग पंखा लगाना',
    jobMoveOutCleaning: 'घर की सफाई', jobPaintBedroom: 'बेडरूम की दीवारें पेंट करें', jobDeepCleanKitchen: 'रसोई की गहरी सफाई',
    jobDescription: 'एक स्थानीय परिवार को भरोसेमंद {category} कारीगर चाहिए। अपने बुनियादी औज़ार लाएँ और समय पर पहुँचें।',
    location: 'स्थान', when: 'समय', budget: 'बजट', household: 'परिवार', positive: 'सकारात्मक', day: 'दिन',
    interestSent: 'रुचि भेजी', imInterested: 'मैं इच्छुक हूँ', viewInterestedWorkers: 'रुचि रखने वाले कारीगर देखें',
    noJobsFound: 'कोई काम नहीं मिला', tryAnother: 'कोई दूसरा कौशल या स्थान आज़माएँ।', safetyFirst: 'आपकी सुरक्षा सबसे पहले',
    familyAlerts: 'परिवार अलर्ट और सुरक्षित भुगतान हमेशा चालू हैं।',
  },
  'ગુજરાતી': {
    workerHome: 'કામદાર હોમ', householdHome: 'ઘર હોમ', available: 'ઉપલબ્ધ', offline: 'ઑફલાઇન',
    walletBalance: 'વૉલેટ બેલેન્સ', pinProtected: 'PIN સુરક્ષિત', addMoney: 'પૈસા ઉમેરો',
    findWorkNearby: 'નજીકનું કામ શોધો', jobsToday: 'આજે 3 કામ', searchSkillLocation: 'કૌશલ્ય અથવા સ્થળથી શોધો',
    painting: 'પેઇન્ટિંગ', plumbing: 'પ્લમ્બિંગ', cleaning: 'સફાઈ', electrical: 'ઇલેક્ટ્રિકલ',
    recommended: 'તમારા માટે કામ', viewAll: 'બધું જુઓ', interested: 'રસ મોકલ્યો',
    nearbyJobs: 'નજીકના કામ', discoverOpportunities: 'તકો શોધો', map: 'નકશો', searchJobs: 'કામ, કૌશલ્ય અથવા વિસ્તાર શોધો',
    all: 'બધા', bestMatch: 'શ્રેષ્ઠ મેળ', jobsNearYou: 'નજીકના કામ',
    myWallet: 'મારું વૉલેટ', safeAndSimple: 'સુરક્ષિત અને સરળ', pinOn: 'PIN ચાલુ', sendToFamily: 'પરિવારને મોકલો',
    familySafety: 'પરિવાર સુરક્ષા લિંક', transactionReceipts: 'વ્યવહારની રસીદો', credit: 'જમા', debit: 'ખર્ચ',
    helpSupport: 'મદદ અને સહાય', weAreHere: 'અમે તમારી મદદ માટે છીએ', online: 'ઑનલાઇન', whatHelp: 'અમે કેવી રીતે મદદ કરી શકીએ?',
    contactCare: 'ગ્રાહક સહાય', callParth: 'પાર્થને કૉલ કરો', whatsapp: 'વોટ્સએપ', emergencySos: 'પરિવારને ઇમરજન્સી SOS',
    jobWallPainting: '2BHK દિવાલ પેઇન્ટિંગ', jobKitchenTap: 'રસોડાનો નળ લીક', jobFanInstallation: 'સીલિંગ પંખો લગાવવો',
    jobMoveOutCleaning: 'ઘરની સફાઈ', jobPaintBedroom: 'બેડરૂમની દિવાલો પેઇન્ટ કરો', jobDeepCleanKitchen: 'રસોડાની ઊંડી સફાઈ',
    jobDescription: 'એક સ્થાનિક પરિવારને વિશ્વસનીય {category} કારીગર જોઈએ છે. તમારા મૂળભૂત સાધનો લાવો અને સમયસર પહોંચો.',
    location: 'સ્થળ', when: 'સમય', budget: 'બજેટ', household: 'પરિવાર', positive: 'સકારાત્મક', day: 'દિવસ',
    interestSent: 'રસ મોકલ્યો', imInterested: 'મને રસ છે', viewInterestedWorkers: 'રસ ધરાવતા કારીગરો જુઓ',
    noJobsFound: 'કોઈ કામ મળ્યું નથી', tryAnother: 'બીજું કૌશલ્ય અથવા સ્થળ અજમાવો.', safetyFirst: 'તમારી સુરક્ષા પ્રથમ',
    familyAlerts: 'પરિવાર એલર્ટ અને સુરક્ષિત ચુકવણી હંમેશા ચાલુ છે.',
  },
  'मराठी': {
    workerHome: 'कामगार होम', householdHome: 'घर होम', available: 'उपलब्ध', offline: 'ऑफलाइन',
    walletBalance: 'वॉलेट शिल्लक', pinProtected: 'पिन सुरक्षित', addMoney: 'पैसे जोडा',
    findWorkNearby: 'जवळचे काम शोधा', jobsToday: 'आज 3 कामे', searchSkillLocation: 'कौशल्य किंवा ठिकाण शोधा',
    painting: 'पेंटिंग', plumbing: 'प्लंबिंग', cleaning: 'स्वच्छता', electrical: 'इलेक्ट्रिकल',
    recommended: 'तुमच्यासाठी शिफारस', viewAll: 'सर्व पहा', interested: 'स्वारस्य पाठवले',
    nearbyJobs: 'जवळची कामे', discoverOpportunities: 'संधी शोधा', map: 'नकाशा', searchJobs: 'काम, कौशल्य किंवा परिसर शोधा',
    all: 'सर्व', bestMatch: 'सर्वोत्तम जुळणी', jobsNearYou: 'जवळची कामे',
    myWallet: 'माझे वॉलेट', safeAndSimple: 'सुरक्षित आणि सोपे', pinOn: 'पिन सुरू', sendToFamily: 'कुटुंबाला पाठवा',
    familySafety: 'कुटुंब सुरक्षा लिंक', transactionReceipts: 'व्यवहाराच्या पावत्या', credit: 'जमा', debit: 'खर्च',
    helpSupport: 'मदत आणि समर्थन', weAreHere: 'आम्ही तुमच्यासाठी येथे आहोत', online: 'ऑनलाइन', whatHelp: 'आम्ही कशी मदत करू?',
    contactCare: 'ग्राहक सेवेशी संपर्क', callParth: 'पार्थला कॉल करा', whatsapp: 'व्हॉट्सॲप', emergencySos: 'कुटुंबाला आपत्कालीन SOS',
    jobWallPainting: '2BHK भिंती रंगवणे', jobKitchenTap: 'स्वयंपाकघरातील नळ गळत आहे', jobFanInstallation: 'सीलिंग फॅन बसवणे',
    jobMoveOutCleaning: 'घराची साफसफाई', jobPaintBedroom: 'बेडरूमच्या भिंती रंगवा', jobDeepCleanKitchen: 'स्वयंपाकघराची खोल साफसफाई',
    jobDescription: 'स्थानिक कुटुंबाला विश्वासू {category} कारागिराची गरज आहे. तुमची मूलभूत साधने आणा आणि वेळेवर पोहोचा.',
    location: 'ठिकाण', when: 'वेळ', budget: 'अंदाजपत्रक', household: 'कुटुंब', positive: 'चांगला', day: 'दिवस',
    interestSent: 'स्वारस्य पाठवले', imInterested: 'मला स्वारस्य आहे', viewInterestedWorkers: 'स्वारस्य असलेले कामगार पहा',
    noJobsFound: 'काम सापडले नाही', tryAnother: 'दुसरे कौशल्य किंवा ठिकाण वापरून पहा.', safetyFirst: 'तुमची सुरक्षा सर्वात आधी',
    familyAlerts: 'कुटुंब सूचना आणि सुरक्षित पेआउट नेहमी सुरू आहेत.',
  },
};

type LanguageContextValue = {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: TranslationKey) => string;
  languages: Language[];
};

const LanguageContext = createContext<LanguageContextValue | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('English');
  const value = useMemo(
    () => ({
      language,
      setLanguage,
      t: (key: TranslationKey) => translations[language][key],
      languages: Object.keys(translations) as Language[],
    }),
    [language],
  );
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) throw new Error('useLanguage must be used within LanguageProvider');
  return context;
}